<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use DB;

class SheduleModels extends Model
{
	protected $table = 't_project'; 
	
}