<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

class OnlySubMenuModels extends Model
{
	protected $table = 't_privileges_sub as a'; 
}
