<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

class MenuOnlyModels extends Model
{
	protected $table = 't_menu'; 
}
