<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

class SubMenuModels extends Model
{
	protected $table = 't_sub_menu as a'; 
}
