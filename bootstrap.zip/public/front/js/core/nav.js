var Nav = new Vue({
    el: '#Nav',
    data: {

    },
    methods: {
    },
    created: function () {
    },
    mounted: function () {  
    },
    updated: function () {
    },
    watch: {

    },
   
})